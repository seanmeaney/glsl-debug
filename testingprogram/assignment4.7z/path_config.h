// #define MATERIAL_DIRECTORY "../"
#define MATERIAL_DIRECTORY "/home/sean/assignment4"
// change to specify your own location here